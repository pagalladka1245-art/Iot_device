# NEREUS Water Pump PWA — ESP32 compatible

The HTML PWA uses the same Firebase Realtime Database control/telemetry/history schema as `WaterPump_ESP32_GeminiADC.ino`. The ESP32 firmware port preserves command IDs and request paths; the app does not need different Firebase paths.

- `index.html` — dashboard, Email/Password authentication, Manual/Auto mode, motor controls, thresholds, Refresh/ACK, calibration and activity history.
- `manifest.webmanifest` and `service-worker.js` — installable PWA assets.
- `FIREBASE_RULES.json` — prototype rules template; replace the device-auth email before publishing.

Configure the Firebase Web App settings inside `index.html`, enable Email/Password authentication, set `devices/pump_001/ownerUid` to the signed-in app user's UID, and publish the rules after replacing the placeholder device-account email. Host via HTTPS (Firebase Hosting recommended); direct `file://` use is unsuitable for Firebase web modules.

## ESP32 calibration

The firmware uses five rapid ADC samples during a single 1 ms excitation pulse, averages them, and applies EMA alpha 0.20. Calibration uses the current average. Capture low/near-empty before full; the ESP32 ADC values are 12-bit (`0..4095`) on the selected classic ESP32 target. The firmware rejects an endpoint span under 80 counts.

The PWA control logic and Firebase paths remain compatible with the ESP32 sketch. The app source included here may still contain Firebase config placeholders; configure it for your existing project before hosting. If your currently hosted PWA is already working and configured, it can remain in place; only the diagnostic label should say “5-read average,” not “median.”

Before commercial deployment, configure TLS certificate verification, review device-specific Firebase rules, and conduct electrical safety testing. This is a prototype, not a certified safety controller.


### ADC estimator note
The matching ESP32 Median ADC firmware sends `adcRaw` as the median of five rapid reads (not the arithmetic average). The optional ADC diagnostic card labels this value as the 5-read median.
